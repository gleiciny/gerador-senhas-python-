
# Gerador de Senhas em Python

## Objetivo
Criar um programa que gera senhas aleatórias e seguras com base em configurações personalizáveis pelo usuário.

## Funcionalidades
- Gerar senhas com caracteres:
  - Letras maiúsculas e minúsculas.
  - Números.
  - Símbolos especiais.
- Definir o comprimento da senha.
- Interface simples no terminal.

## Cronograma
- **Semana 1**: Configuração inicial e lógica básica de geração de senhas.
- **Semana 2**: Adicionar opções personalizáveis.
- **Semana 3**: Documentação e testes.
