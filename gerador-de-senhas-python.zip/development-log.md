
# Registro de Desenvolvimento

## Dia 1
- Criado o repositório local.
- Implementada a lógica básica de geração de senhas.

## Dia 2
- Adicionadas opções personalizáveis para incluir/excluir tipos de caracteres.

## Reflexões
- A utilização de versões separadas permitiu testar funcionalidades sem comprometer o código principal.
